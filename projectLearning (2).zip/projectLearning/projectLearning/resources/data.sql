INSERT INTO USERTABLE (id,user_name, password) VALUES
  (1,'ankush', 'ankush123'),
  (2,'sharmila', 'shar123' ),(3,'ram', 'ram123');
  
  INSERT INTO ALLOANS (id,firstName, lastName,address) VALUES
  (1111l,'ankush', 'arora','dehradun'),
  (2222l,'sharmila', 'shar123','pune' ),(3333,'ram', 'ram123','noida');