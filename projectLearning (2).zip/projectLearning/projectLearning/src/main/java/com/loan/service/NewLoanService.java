package com.loan.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.loan.entity.NewLoan;
import com.loan.entity.SearchLoan;
import com.loan.repository.NewLoanRepository;

@Service
public class NewLoanService {

	@Autowired
	private NewLoanRepository newLoanRepository;

	public void initNewLoan() {
		NewLoan loan1 = new NewLoan();
		loan1.setLoanNumber(123);
		loan1.setFirstName("ankush");
		loan1.setLastName("arora");
		loan1.setAddress("123 dehradun");
		loan1.setLoanType("Education Loan");
		loan1.setLoanAmount(200000);
		newLoanRepository.save(loan1);

		NewLoan loan2 = new NewLoan();
		loan2.setLoanNumber(456);
		loan2.setFirstName("sharmila");
		loan2.setLastName("m");
		loan2.setAddress("567 chennai");
		loan2.setLoanType("Business Loan");
		loan2.setLoanAmount(300000);
		newLoanRepository.save(loan2);
	}

	public List<NewLoan> getAllLoansDetails() {
		List<NewLoan> userList = newLoanRepository.findAll();

		if (userList.size() > 0) {
			return userList;
		} else {
			return new ArrayList<NewLoan>();
		}
	}

	public NewLoan loanIsPresentOrNot(SearchLoan searchLoan) {
		List<NewLoan> userList = newLoanRepository.findAll();
		for (NewLoan each : userList) {
			if (each.getFirstName().equals(searchLoan.getFirstName())
					&& each.getLastName().equals(searchLoan.getLastName())
					&& each.getLoanNumber() == searchLoan.getLoanNumber()) {
				return each;
			}
		}
		return null;
	}

	public NewLoan addnewLoanDetails(NewLoan newLoan) {
		newLoanRepository.save(newLoan);
		return newLoan;
	}

}
