package com.loan.controller;

import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.loan.entity.NewLoan;
import com.loan.entity.SearchLoan;
import com.loan.entity.AuthRequest;
import com.loan.entity.AuthResponse;
import com.loan.entity.User;
import com.loan.service.CustomUserService;
import com.loan.service.NewLoanService;
import com.loan.util.JwtUtil;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class LoanController {

	@Autowired
	private JwtUtil jwtUtil;

	@Autowired
	private CustomUserService userService;

	@Autowired
	private AuthenticationManager authenticationmanager;

	@Autowired
	private NewLoanService newLoanService;

	@PostMapping("/searchLoanExist")
	public ResponseEntity<?> searchLoanInformation(@RequestBody SearchLoan searchLoan) {
		NewLoan present = null;
		present = newLoanService.loanIsPresentOrNot(searchLoan);
		if (present != null)
			return new ResponseEntity<NewLoan>(present, new HttpHeaders(), HttpStatus.OK);
		return new ResponseEntity<String>("Loan is not found ", new HttpHeaders(), HttpStatus.OK);
	}

	@GetMapping("/getAllLoans")
	public ResponseEntity<List<NewLoan>> getAllLoans() {
		List<NewLoan> list = newLoanService.getAllLoansDetails();
		return new ResponseEntity<List<NewLoan>>(list, new HttpHeaders(), HttpStatus.OK);
	}

	@PostConstruct
	public void addDetails() {
		userService.initUsers();
		newLoanService.initNewLoan();
		System.out.println("Running properly");
	}

	@GetMapping("/getAllUsers")
	public ResponseEntity<List<User>> getAllUsers() {
		List<User> list = userService.getAllUsersDetails();
		return new ResponseEntity<List<User>>(list, new HttpHeaders(), HttpStatus.OK);
	}

	@PostMapping("/addNewUser")
	public ResponseEntity<User> addNewUser(@RequestBody User user) {
		userService.addNewUser(user);
		return new ResponseEntity<User>(user, new HttpHeaders(), HttpStatus.OK);
	}

	@PostMapping("addNewLoan")
	public NewLoan adddNewLoan(@RequestBody NewLoan newLoan) {
		newLoanService.addnewLoanDetails(newLoan);
		return newLoan;
	}

	@PostMapping("/authenticateUser")
	public User authenticateUser(@RequestBody User user) {
		User foundUser = userService.getAllUsers(user.getUserName(), user.getPassword());
		if (foundUser != null)
			return foundUser;

		return null;
	}

	@PostMapping("/authenticate")
	public ResponseEntity<?> generateToken(@RequestBody AuthRequest authRequest) throws Exception {
		try {
			authenticationmanager.authenticate(
					new UsernamePasswordAuthenticationToken(authRequest.getUserName(), authRequest.getPassword()));
		} catch (Exception ex) {
			throw new Exception("Invalid username and password");
		}
		String token = jwtUtil.generateToken(authRequest.getUserName());
		return new ResponseEntity<>(new AuthResponse(token), HttpStatus.OK);
	}

	@GetMapping("/{id}")
	public ResponseEntity<User> getEmployeeById(@PathVariable("id") Integer id) {
		User entity = userService.getEmployeeById(id);

		return new ResponseEntity<User>(entity, new HttpHeaders(), HttpStatus.OK);
	}
}
